Image To Video Converter (C#)

1.After Extracting install the MovieMaker Setup
2.Open the file Visual Studio
3.Select toolbar --> Right Click on Components Select choose iteams --> COM Components --> select  MovieMaker-->OK
4.Run the code 
5.Click Add --> Select the image(You can costomise the image run time)
6.Click Play (Preview)
7.Click on convet to conver into MP4 File
4.Wait for Complete Message