﻿namespace Image_To_Video_Converter
{
    partial class ImageToVideoConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImageToVideoConverter));
            this.VideoMaker = new AxTimelineAxLib.AxTimelineControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bntAdd = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bntPlay = new System.Windows.Forms.Button();
            this.bntStop = new System.Windows.Forms.Button();
            this.bntConvert = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.VideoMaker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // VideoMaker
            // 
            this.VideoMaker.Enabled = true;
            this.VideoMaker.Location = new System.Drawing.Point(12, 178);
            this.VideoMaker.Name = "VideoMaker";
            this.VideoMaker.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("VideoMaker.OcxState")));
            this.VideoMaker.Size = new System.Drawing.Size(888, 367);
            this.VideoMaker.TabIndex = 0;
            this.VideoMaker.OnConvertProgress += new AxTimelineAxLib._ITimelineControlEvents_OnConvertProgressEventHandler(this.VideoMaker_OnConvertProgress);
            this.VideoMaker.OnConvertCompleted += new System.EventHandler(this.VideoMaker_OnConvertCompleted);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox1.Location = new System.Drawing.Point(914, 178);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(373, 366);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bntAdd
            // 
            this.bntAdd.Location = new System.Drawing.Point(12, 85);
            this.bntAdd.Name = "bntAdd";
            this.bntAdd.Size = new System.Drawing.Size(122, 41);
            this.bntAdd.TabIndex = 2;
            this.bntAdd.Text = "Add Image";
            this.bntAdd.UseVisualStyleBackColor = true;
            this.bntAdd.Click += new System.EventHandler(this.bntAdd_Click);
            // 
            // bntPlay
            // 
            this.bntPlay.Location = new System.Drawing.Point(163, 85);
            this.bntPlay.Name = "bntPlay";
            this.bntPlay.Size = new System.Drawing.Size(125, 40);
            this.bntPlay.TabIndex = 3;
            this.bntPlay.Text = "Play";
            this.bntPlay.UseVisualStyleBackColor = true;
            this.bntPlay.Click += new System.EventHandler(this.bntPlay_Click);
            // 
            // bntStop
            // 
            this.bntStop.Location = new System.Drawing.Point(325, 85);
            this.bntStop.Name = "bntStop";
            this.bntStop.Size = new System.Drawing.Size(120, 40);
            this.bntStop.TabIndex = 4;
            this.bntStop.Text = "Stop";
            this.bntStop.UseVisualStyleBackColor = true;
            this.bntStop.Click += new System.EventHandler(this.bntStop_Click);
            // 
            // bntConvert
            // 
            this.bntConvert.Location = new System.Drawing.Point(470, 85);
            this.bntConvert.Name = "bntConvert";
            this.bntConvert.Size = new System.Drawing.Size(138, 40);
            this.bntConvert.TabIndex = 5;
            this.bntConvert.Text = "Convert";
            this.bntConvert.UseVisualStyleBackColor = true;
            this.bntConvert.Click += new System.EventHandler(this.bntConvert_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(626, 85);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(133, 40);
            this.progressBar1.TabIndex = 6;
            // 
            // ImageToVideoConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 557);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.bntConvert);
            this.Controls.Add(this.bntStop);
            this.Controls.Add(this.bntPlay);
            this.Controls.Add(this.bntAdd);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.VideoMaker);
            this.Name = "ImageToVideoConverter";
            this.Text = "Image To Video Converter";
            this.Load += new System.EventHandler(this.ImageToVideoConverter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VideoMaker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxTimelineAxLib.AxTimelineControl VideoMaker;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bntAdd;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button bntPlay;
        private System.Windows.Forms.Button bntStop;
        private System.Windows.Forms.Button bntConvert;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}

