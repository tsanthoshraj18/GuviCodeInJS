﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Image_To_Video_Converter
{
    public partial class ImageToVideoConverter : Form
    {
        public ImageToVideoConverter()
        {
            InitializeComponent();
        }

        private void ImageToVideoConverter_Load(object sender, EventArgs e)
        {
            VideoMaker.SetPreviewWnd((int)pictureBox1.Handle);
        }

        private void bntAdd_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "All Files (*.*)|*.*|JPEG (*.jpg) |*.jpg||";
            if (openFileDialog1.ShowDialog() ==DialogResult.OK)
            {

                string strFile = openFileDialog1.FileName;

                VideoMaker.SetVideoTrackResolution(1024, 768);

                VideoMaker.AddImageClip(3, strFile, 0, 1, 0);


            }
        }

        private void bntPlay_Click(object sender, EventArgs e)
        {
            VideoMaker.Play();
        }

        private void bntStop_Click(object sender, EventArgs e)
        {
            VideoMaker.Stop();
        }

        private void bntConvert_Click(object sender, EventArgs e)
        {
            VideoMaker.OutputType = 2;
            VideoMaker.MP4Height = 768;
            VideoMaker.MP4Width = 1024;

            saveFileDialog1.Filter = "MP4 File (*.mp4) |*.mp4||";

            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int iresult = VideoMaker.Save(saveFileDialog1.FileName);
            }
        }

        private void VideoMaker_OnConvertProgress(object sender, AxTimelineAxLib._ITimelineControlEvents_OnConvertProgressEvent e)
        {
            progressBar1.Value = e.progress;
        }

        private void VideoMaker_OnConvertCompleted(object sender, EventArgs e)
        {
            MessageBox.Show("Completed");
        }
    }
}
